let selected_value = document.querySelector("#slected_value");
let district_code = document.querySelector("#district_code");
let increase = document.querySelector("#increase");
let extended_div = document.querySelector(".extended_div");
let id = 0;

selected_value.addEventListener("click", function () {
  selected_value.value == "Bagerhat" ? (district_code.value = "BD4001") : "";
  selected_value.value == "Bandarban" ? (district_code.value = "BD2003") : "";
  selected_value.value == "Barguna" ? (district_code.value = "BD1004") : "";
  selected_value.value == "Barishal" ? (district_code.value = "BD1006") : "";
  selected_value.value == "Bhola" ? (district_code.value = "BD1009") : "";
  selected_value.value == "Bogura" ? (district_code.value = "BD5010") : "";
  selected_value.value == "Brahamanbaria"
    ? (district_code.value = "BD2012")
    : "";
  selected_value.value == "Chandpur" ? (district_code.value = "BD2013") : "";
  selected_value.value == "Chattogram" ? (district_code.value = "BD2015") : "";
  selected_value.value == "Chuadanga" ? (district_code.value = "BD4018") : "";
  selected_value.value == "Cumilla" ? (district_code.value = "BD2019") : "";
  selected_value.value == "Cox's Bazar" ? (district_code.value = "BD2022") : "";

  selected_value.value == "Dhaka" ? (district_code.value = "BD3026") : "";
  selected_value.value == "Dinajpur" ? (district_code.value = "BD5527") : "";
  selected_value.value == "Faridpur" ? (district_code.value = "BD3029") : "";
  selected_value.value == "Feni" ? (district_code.value = "BD2030") : "";
  selected_value.value == "Gaibandha" ? (district_code.value = "BD5532") : "";
  selected_value.value == "Gazipur" ? (district_code.value = "BD3033") : "";
  selected_value.value == "Gopalganj" ? (district_code.value = "BD3035") : "";
  selected_value.value == "Habiganj" ? (district_code.value = "BD6036") : "";

  selected_value.value == "Jamalpur" ? (district_code.value = "BD4539") : "";
  selected_value.value == "Jashore" ? (district_code.value = "BD4041") : "";
  selected_value.value == "Jhalokati" ? (district_code.value = "BD1042") : "";
  selected_value.value == "Jhenaidah" ? (district_code.value = "BD4044") : "";
  selected_value.value == "Joypurhat" ? (district_code.value = "BD5038") : "";
  selected_value.value == "Khagrachhari"
    ? (district_code.value = "BD2046")
    : "";
  selected_value.value == "Khulna" ? (district_code.value = "BD4047") : "";
  selected_value.value == "Kishoreganj" ? (district_code.value = "BD3048") : "";
  selected_value.value == "Kurigram" ? (district_code.value = "BD5549") : "";
  selected_value.value == "Kushtia" ? (district_code.value = "BD4050") : "";

  selected_value.value == "Lakshmipur" ? (district_code.value = "BD2051") : "";
  selected_value.value == "Lalmonirhat" ? (district_code.value = "BD5552") : "";
  selected_value.value == "Madaripur" ? (district_code.value = "BD3054") : "";
  selected_value.value == "Magura" ? (district_code.value = "BD4055") : "";
  selected_value.value == "Manikganj" ? (district_code.value = "BD3056") : "";
  selected_value.value == "Maulvibazar" ? (district_code.value = "BD6058") : "";
  selected_value.value == "Meherpur" ? (district_code.value = "BD4057") : "";
  selected_value.value == "Munshiganj" ? (district_code.value = "BD3059") : "";
  selected_value.value == "Mymensingh" ? (district_code.value = "BD4561") : "";
  selected_value.value == "Naogaon" ? (district_code.value = "BD5064") : "";

  selected_value.value == "Narail" ? (district_code.value = "BD4065") : "";
  selected_value.value == "Narayanganj" ? (district_code.value = "BD3067") : "";
  selected_value.value == "Narsingdi" ? (district_code.value = "BD3068") : "";
  selected_value.value == "Natore" ? (district_code.value = "BD5069") : "";
  selected_value.value == "Nawabganj" ? (district_code.value = "BD5070") : "";
  selected_value.value == "Netrakona" ? (district_code.value = "BD4572") : "";
  selected_value.value == "Nilphamari" ? (district_code.value = "BD5573") : "";
  selected_value.value == "Noakhali" ? (district_code.value = "BD2075") : "";
  selected_value.value == "Pabna" ? (district_code.value = "BD5076") : "";

  selected_value.value == "Panchagarh" ? (district_code.value = "BD5577") : "";
  selected_value.value == "Patuakhali" ? (district_code.value = "BD1078") : "";
  selected_value.value == "Pirojpur" ? (district_code.value = "BD1079") : "";
  selected_value.value == "Rajbari" ? (district_code.value = "BD3082") : "";
  selected_value.value == "Rajshahi" ? (district_code.value = "BD5081") : "";
  selected_value.value == "Rangamati" ? (district_code.value = "BD2084") : "";
  selected_value.value == "Rangpur" ? (district_code.value = "BD5585") : "";
  selected_value.value == "Satkhira" ? (district_code.value = "BD4087") : "";
  selected_value.value == "Shariatpur" ? (district_code.value = "BD3086") : "";
  selected_value.value == "Sherpur" ? (district_code.value = "BD4589") : "";
  selected_value.value == "Sirajganj" ? (district_code.value = "BD5088") : "";
  selected_value.value == "Sunamganj" ? (district_code.value = "BD6090") : "";
  selected_value.value == "Sylhet" ? (district_code.value = "BD6091") : "";
  selected_value.value == "Tangail" ? (district_code.value = "BD3093") : "";
  selected_value.value == "Thakurgaon" ? (district_code.value = "BD5594") : "";
});

function incraseFunction() {
  id += 1;
  html = `
  <div>
  <select name="" id="slected_value_${id}">
    <option value="Bagerhat">Bagerhat</option>
    <option value="Bandarban">Bandarban</option>
    <option value="Barguna">Barguna</option>
    <option value="Barishal">Barishal</option>
    <option value="Bhola">Bhola</option>
    <option value="Brahamanbaria">Brahamanbaria</option>
    <option value="Chandpur">Chandpur</option>
    <option value="Chattogram">Chattogram</option>
    <option value="Chuadanga">Chuadanga</option>
    <option value="Cumilla">Cumilla</option>
    <option value="Cox's Bazar">Cox's Bazar</option>
    <option value="Dhaka">Dhaka</option>

    <option value="Dinajpur">Dinajpur</option>
    <option value="Faridpur">Faridpur</option>
    <option value="Feni">Feni</option>
    <option value="Gaibandha">Gaibandha</option>
    <option value="Gazipur">Gazipur</option>
    <option value="Gopalganj">Gopalganj</option>
    <option value="Habiganj">Habiganj</option>
    <option value="Jamalpur">Jamalpur</option>
    <option value="Jashore">Jashore</option>
    <option value="Jhalokati">Jhalokati</option>
    <option value="Jhenaidah">Jhenaidah</option>
    <option value="Joypurhat">Joypurhat</option>
    <option value="Khagrachhari">Khagrachhari</option>
    <option value="Khulna">Khulna</option>
    <option value="Kishoreganj">Kishoreganj</option>
    <option value="Kurigram">Kurigram</option>
    <option value="Kushtia">Kushtia</option>

    <option value="Lakshmipur">Lakshmipur</option>
    <option value="Lalmonirhat">Lalmonirhat</option>
    <option value="Madaripur">Madaripur</option>
    <option value="Magura">Magura</option>
    <option value="Manikganj">Manikganj</option>
    <option value="Maulvibazar">Maulvibazar</option>
    <option value="Meherpur">Meherpur</option>
    <option value="Munshiganj">Munshiganj</option>
    <option value="Mymensingh">Mymensingh</option>
    <option value="Naogaon">Naogaon</option>

    <option value="Narail">Narail</option>
    <option value="Narayanganj">Narayanganj</option>
    <option value="Narsingdi">Narsingdi</option>
    <option value="Netrakona">Netrakona</option>
    <option value="Nilphamari">Nilphamari</option>
    <option value="Noakhali">Noakhali</option>
    <option value="Pabna">Pabna</option>

    <option value="Panchagarh">Panchagarh</option>
    <option value="Patuakhali">Patuakhali</option>
    <option value="Pirojpur">Pirojpur</option>
    <option value="Rajbari">Rajbari</option>
    <option value="Rajshahi">Rajshahi</option>
    <option value="Rangamati">Rangamati</option>
    <option value="Rangpur">Rangpur</option>
    <option value="Satkhira">Satkhira</option>
    <option value="Shariatpur">Shariatpur</option>
    <option value="Sherpur">Sherpur</option>
    <option value="Sirajganj">Sirajganj</option>
    <option value="Sunamganj">Sunamganj</option>
    <option value="Sylhet">Sylhet</option>
    <option value="Tangail">Tangail</option>
    <option value="Thakurgaon">Thakurgaon</option>
  </select>

  <input type="text" id="district_code_${id}" />
</div>
  `;

  extended_div.insertAdjacentHTML("afterbegin", html);
  test(`slected_value_${id}`, `district_code_${id}`);
}

function test(value_1, value_2) {
  let value_10 = document.querySelector(`#` + value_1);
  let value_11 = document.querySelector(`#` + value_2);

  value_10.addEventListener("click", function () {
    value_10.value == "Bagerhat" ? (value_11.value = "BD4001") : "";
    value_10.value == "Bandarban" ? (value_11.value = "BD2003") : "";
    value_10.value == "Barguna" ? (value_11.value = "BD1004") : "";
    value_10.value == "Barishal" ? (value_11.value = "BD1006") : "";
    value_10.value == "Bhola" ? (value_11.value = "BD1009") : "";
    value_10.value == "Bogura" ? (value_11.value = "BD5010") : "";
    value_10.value == "Brahamanbaria" ? (value_11.value = "BD2012") : "";
    value_10.value == "Chandpur" ? (value_11.value = "BD2013") : "";
    value_10.value == "Chattogram" ? (value_11.value = "BD2015") : "";
    value_10.value == "Chuadanga" ? (value_11.value = "BD4018") : "";
    value_10.value == "Cumilla" ? (value_11.value = "BD2019") : "";
    value_10.value == "Cox's Bazar" ? (value_11.value = "BD2022") : "";

    value_10.value == "Dhaka" ? (value_11.value = "BD3026") : "";
    value_10.value == "Dinajpur" ? (value_11.value = "BD5527") : "";
    value_10.value == "Faridpur" ? (value_11.value = "BD3029") : "";
    value_10.value == "Feni" ? (value_11.value = "BD2030") : "";
    value_10.value == "Gaibandha" ? (value_11.value = "BD5532") : "";
    value_10.value == "Gazipur" ? (value_11.value = "BD3033") : "";
    value_10.value == "Gopalganj" ? (value_11.value = "BD3035") : "";
    value_10.value == "Habiganj" ? (value_11.value = "BD6036") : "";

    value_10.value == "Jamalpur" ? (value_11.value = "BD4539") : "";
    value_10.value == "Jashore" ? (value_11.value = "BD4041") : "";
    value_10.value == "Jhalokati" ? (value_11.value = "BD1042") : "";
    value_10.value == "Jhenaidah" ? (value_11.value = "BD4044") : "";
    value_10.value == "Joypurhat" ? (value_11.value = "BD5038") : "";
    value_10.value == "Khagrachhari" ? (value_11.value = "BD2046") : "";
    value_10.value == "Khulna" ? (value_11.value = "BD4047") : "";
    value_10.value == "Kishoreganj" ? (value_11.value = "BD3048") : "";
    value_10.value == "Kurigram" ? (value_11.value = "BD5549") : "";
    value_10.value == "Kushtia" ? (value_11.value = "BD4050") : "";

    value_10.value == "Lakshmipur" ? (value_11.value = "BD2051") : "";
    value_10.value == "Lalmonirhat" ? (value_11.value = "BD5552") : "";
    value_10.value == "Madaripur" ? (value_11.value = "BD3054") : "";
    value_10.value == "Magura" ? (value_11.value = "BD4055") : "";
    value_10.value == "Manikganj" ? (value_11.value = "BD3056") : "";
    value_10.value == "Maulvibazar" ? (value_11.value = "BD6058") : "";
    value_10.value == "Meherpur" ? (value_11.value = "BD4057") : "";
    value_10.value == "Munshiganj" ? (value_11.value = "BD3059") : "";
    value_10.value == "Mymensingh" ? (value_11.value = "BD4561") : "";
    value_10.value == "Naogaon" ? (value_11.value = "BD5064") : "";

    value_10.value == "Narail" ? (value_11.value = "BD4065") : "";
    value_10.value == "Narayanganj" ? (value_11.value = "BD3067") : "";
    value_10.value == "Narsingdi" ? (value_11.value = "BD3068") : "";
    value_10.value == "Natore" ? (value_11.value = "BD5069") : "";
    value_10.value == "Nawabganj" ? (value_11.value = "BD5070") : "";
    value_10.value == "Netrakona" ? (value_11.value = "BD4572") : "";
    value_10.value == "Nilphamari" ? (value_11.value = "BD5573") : "";
    value_10.value == "Noakhali" ? (value_11.value = "BD2075") : "";
    value_10.value == "Pabna" ? (value_11.value = "BD5076") : "";

    value_10.value == "Panchagarh" ? (value_11.value = "BD5577") : "";
    value_10.value == "Patuakhali" ? (value_11.value = "BD1078") : "";
    value_10.value == "Pirojpur" ? (value_11.value = "BD1079") : "";
    value_10.value == "Rajbari" ? (value_11.value = "BD3082") : "";
    value_10.value == "Rajshahi" ? (value_11.value = "BD5081") : "";
    value_10.value == "Rangamati" ? (value_11.value = "BD2084") : "";
    value_10.value == "Rangpur" ? (value_11.value = "BD5585") : "";
    value_10.value == "Satkhira" ? (value_11.value = "BD4087") : "";
    value_10.value == "Shariatpur" ? (value_11.value = "BD3086") : "";
    value_10.value == "Sherpur" ? (value_11.value = "BD4589") : "";
    value_10.value == "Sirajganj" ? (value_11.value = "BD5088") : "";
    value_10.value == "Sunamganj" ? (value_11.value = "BD6090") : "";
    value_10.value == "Sylhet" ? (value_11.value = "BD6091") : "";
    value_10.value == "Tangail" ? (value_11.value = "BD3093") : "";
    value_10.value == "Thakurgaon" ? (value_11.value = "BD5594") : "";
  });
}
